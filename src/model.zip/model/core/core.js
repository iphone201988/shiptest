export default class CoreModel {

	constructor(id){
		this.id = id
	}

	isValid(){
		return true
	}
}

