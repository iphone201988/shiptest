import CoreModel from "../core/core";
import FirestoreCollection from "../../helpers/firebase/firestore/firestore_collection";
import {ValueOrDefault} from "../../helpers/data/mapper";
import {AUTH_METHODS, INTEGRATION_PROVIDERS, INTEGRATION_TYPES} from "../../constants/options/integrations";

const UNKNOWN = "unknown"

const IntegrationType = (value) => {
    return ValueOrDefault(INTEGRATION_TYPES, value, UNKNOWN)
}

const IntegrationProvider = (value) => {
    return ValueOrDefault(INTEGRATION_PROVIDERS, value, UNKNOWN)
}

const AuthMethod = (value) => {
    return ValueOrDefault(AUTH_METHODS, value, UNKNOWN)
}

export default class CompanyIntegration extends CoreModel {

    static collection = new FirestoreCollection("CompanyIntegrations", CompanyIntegration,[])

    constructor(id, data) {
        data = data || {}
        super(id)
        this.provider = IntegrationProvider(data.provider)
        this.type = IntegrationType(data.type)
        this.status = data.status
        this.auth_method = AuthMethod(data.auth_method)
        this.credentials = data.credentials
    }

    isValid = () =>{
        return true
    }
}