import {BaseShipment} from "./baseShipment";
import {SHIPMENT_STATE} from "../../constants/options/shipping";
import FirestoreCollection, {FireQuery} from "../../helpers/firebase/firestore/firestore_collection";


export default class Shipment extends BaseShipment{

  static collection = new FirestoreCollection("Shipments", Shipment,
      [new FireQuery('type', '==', SHIPMENT_STATE.shipment.key)])

  constructor(id, data) {
    data = data || {}
    super(id, data)
    this.type = SHIPMENT_STATE.shipment.key
    this.quote_request = data.quote_request
  }
}
