
export  class Tax {
  constructor(data) {
    data = data || {}
    this.name = data.name
    this.rate = data.rate
    this.amount = data.amount
  }

  calculate_tax(value){
    this.amount =  value * this.rate
  }
}

export default class Rate {
  constructor(data) {
    data = data || {}
    this.currency_code = data.currency_code || ""
    this.carrier_rate = data.carrier_rate || 0
    this.carrier_fuel_rate = data.carrier_fuel_rate || 0
    this.shipper_rate = data.shipper_rate || 0
    this.service_fee_rate = data.service_fee_rate || 0
    this.service_fee = data.service_fee || 0
    this.taxes = (data.taxes || []).map(tax => new Tax(tax))
    this.total_taxes = (data.taxes || []).map(tax=> tax.amount).reduce((a,b) => a + b, 0)
    this.total = data.total || data.shipper_rate + this.total_taxes
  }

  calculate_taxes = (subtotal) => {
    return this.taxes.map(tax => subtotal * tax.rate)
  }
}