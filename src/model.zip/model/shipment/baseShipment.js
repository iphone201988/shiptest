import Rate from "./rate";
import CoreModel from "../core/core";
import {Location, LocationType, Position} from "../location/location";
import {TimeStamp} from "../../helpers/data/format";

export var nanoid = require('nanoid');

export class ShipmentLocation {
	constructor(data){
		data = data || {}
		this.location_type = LocationType(data.location_type)
		this.location = new Location(data.location)
		this.is_start = data.is_start || false
		this.is_end = !data.is_start ? data.is_end || false : false
		this.pickups = data.pickups || []
		this.drops = data.drops || []
		this.pickups_details = data.pickups || []
		this.drops_details = data.drops || []
		this.before = data.before || []
		this.address_info = data.address_info
		this.earliest_access_time = TimeStamp(data.earliest_access_time)
		this.latest_access_time = TimeStamp(data.latest_access_time)
		this.earliest_estimated_arrival_time = TimeStamp(data.earliest_estimated_arrival_time)
		this.latest_estimated_arrival_time = TimeStamp(data.latest_estimated_arrival_time)
		this.arrival_time = TimeStamp(data.arrival_time)
		this.start_loading_time = TimeStamp(data.start_loading_time)
		this.end_loading_time = TimeStamp(data.end_loading_time)
		this.departure_time = TimeStamp(data.departure_time)
	}
	setLocation = (location) => {
		this.location = new Location(location)
	}
}

const FreightType = () => {

}

class TrackingData  {
	constructor(data) {
		data = data || {}
		this.position = new Position(data.position || {})
		this.eta = TimeStamp(data.eta || 0)
	}
}

export class BaseShipment extends CoreModel  {

	constructor(id, data, {expand=true} = {}) {
		data = data || {}

		super(id, "Shipments")
		if (data){

			if (data.destinations){
				// TODO: temporarly -- remove this section
				if (!data.origin){
					data.origin = data.destinations[0]
				}
				if (!data.destination){
					data.destination = data.destinations[data.destinations.length-1]
				}

			}

			try{
				this.type = data.type
				this.active = data.active || false
				this.status = data.status
				this.freight_type = data.freight_type
				this.trailer_type = data.trailer_type
				this.trailer_length = data.trailer_length
				// this.trailer_types = (data.trailer_types || []).filter(trailer_type => TRAILER_TYPES[trailer_type])
				this.trailer_types = data.trailer_types || []
				this.handling_units = data.handling_units || []
				this.origin = (data.origin instanceof ShipmentLocation)  ? data.origin  : new ShipmentLocation(data.origin)
				this.destination =  (data.destination instanceof ShipmentLocation)  ? data.destination  : new ShipmentLocation(data.destination)
				this.stops = (data.stops || data.destinations || []).map(location => new ShipmentLocation(location))
				this.shipment_services = data.shipment_services || []
				this.shipper = data.shipper
				this.carrier = data.carrier
				this.weight = data.weight
				this.rate = new Rate(data.rate)
				this.itinerary_sequence = data.itinerary_sequence || []
				this.billing_profile = data.billing_profile
				this.locations=[]
				this.tracking= new TrackingData(data.tracking || {})
				if (expand && data){this.expand()}
			}catch (e) {
				this.invalid = true
			}

		}else{
			this.invalid = true
		}
	}

	isValid = () =>{
		return !(this.invalid == true)
	}


	compact =() =>{
		// TODO:  create another function to convert to JSON  and keep Compact as  BaseShipment without locations
		this.locations = []
		const compact = JSON.parse(JSON.stringify(this))
		return compact
	}

	expand = () => {
		/*
		* */

		// const destinations = []
		try{
			// this.itinerary_sequence.waypoints.forEach(waypoint => {
			// 	const destination = this.getDestination(waypoint.id)
			// 	if (destination){
			// 		destination.pickups = this.handling_units.filter(hu => destination.pickups.includes(hu.id))
			// 		destination.drops = this.handling_units.filter(hu => destination.drops.includes(hu.id))
			// 		this.locations.push(destination)
			// 	}
			// })
			//TODO: function to sort stops based on waypoints order

			this.destinations().forEach(destination => {
				// const destination = this.getDestination(waypoint.id)
				if (destination){
					destination.pickups_details = this.handling_units.filter(hu => destination.pickups.includes(hu.id))
					destination.drops_details = this.handling_units.filter(hu => destination.drops.includes(hu.id))
				}
			})

		}catch (e) {
			let a= 1
		}

	}

	StartLocation = () => {
		return this.origin
	}

	EndLocation = () => {
		return this.destination
	}

	StopLocations = () => {
		return this.stops || []
	}

	destinations = () => {
		let destinations = []
		destinations.push(this.StartLocation())
		destinations = destinations.concat(this.StopLocations())
		// destinations.push(this.EndLocation())
		return destinations
	}

	getDestination = (id) =>{
		try{
		return Object.assign({}, this.destinations().filter(location => location.id === id)[0]);
			return
		}catch (e) {
			return undefined
		}
	}

	static getWeight(handling_units){
		return Object.values(handling_units).map(hu => (hu.weight || 0) * (hu.quantity || 0)).reduce((a,b) => a + b, 0)
	}

	updateWeight(){
		this.weight =  this.getWeight(this.handling_units)
	}

	setLocationPickupsAndDrops = () => {
		const locationPickups = {}
		const locationDrops = {}
		this.handling_units.map( hu => {
			if (hu.origin_location){
				if (Array.isArray(locationPickups[hu.origin_location])){
					locationPickups[hu.origin_location].push(hu.id)
				}else{
					locationPickups[hu.origin_location] = [hu.id]
				}
			}
			if (hu.destination_location){
				if (Array.isArray(locationDrops[hu.destination_location])){
					locationDrops[hu.destination_location].push(hu.id)
				}else{
					locationDrops[hu.destination_location] = [hu.id]
				}
			}
		})
		this.destinations().map(destination => {
			destination.pickups = locationPickups[(destination.location || {}).id] || []
			destination.drops = locationDrops[(destination.location || {}).id] || []
		})

	}


}
