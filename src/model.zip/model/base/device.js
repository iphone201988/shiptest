import CoreModel from "../core/core";
import {TimeStamp} from "../../helpers/data/format";
import FirestoreCollection from "../../helpers/firebase/firestore/firestore_collection";


export class TrackingProfile{
	constructor(data){
		this.report_period = data.report_period
	}
}

export class DeviceProfile{
	constructor(data){
		this.name = data.name || ""
		this.model = data.model || ""
		this.brand = data.brand || ""
	}
}

export default class Device extends CoreModel {

	static collection = new FirestoreCollection("Devices", Device,[])

	constructor(id=undefined, data){
		super(id)
		try {
			this.device_id = data.device_id
			this.status = data.status || undefined
			this.profile = new DeviceProfile(data.profile)
			this.tracking_profile = new TrackingProfile(data.tracking_profile)
			this.device_type = data.device_type || ""
			this.company = data.company || ""
			this.asset = data.asset || ""
			this.track_data = data.track_data || {}
			this.last_report_date = TimeStamp(data.last_report_date)
		}catch (e) {
			this.invalid = true
		}
	}

	isValid = () =>{
		return !this.invalid
	}


}