import CoreModel from "../core/core";


export class UserProfile{

  constructor(data){
    data = data || {}
    this.first_name = data.first_name || ""
    this.last_name = data.last_name || ""
    this.email = data.email || ""
    this.phone = data.phone || ""
    this.fax = data.fax || ""
  }

}

export default class User extends CoreModel {

  constructor(id, data){
    super(id)
    data = data || {}
    this.account_status = data.account_status || ""
    this.confirmed = data.confirmed || false
    this.firebase_uid = data.firebase_uid || ""
    this.profile = new UserProfile(data.profile || {})
    this.roles = data.roles || []
    this.role_types = data.role_types || []
  }
}
