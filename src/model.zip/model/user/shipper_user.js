import User from './user'
import Shipper from '../shipper/shipper'

export default class ShipperUser extends User{

  constructor(data){
    data = data || {}
    super(data);
    this.shipper = new Shipper(data.id, data.shipper || {})
  }
}

