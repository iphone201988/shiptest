import User from './user'
import Carrier from '../carrier/carrier'
import {mapToCarrierRoleObject} from "../carrier/role/util";
import CarrierUserRole from "../carrier/role/carrier_user_role";
import FirestoreCollection, {FireQuery} from "../../helpers/firebase/firestore/firestore_collection";
import {SHIPMENT_STATE} from "../../constants/options/shipping";


export default class CarrierUser extends User{

  static collection = new FirestoreCollection("Users", CarrierUser,[])

  constructor(id, userData){
    userData = userData || {}
    super(id, userData);
    try{
      this.roles = userData.roles.map(role_data => mapToCarrierRoleObject(role_data))
    }catch (e) {
      this.roles = []
  }



  }
}