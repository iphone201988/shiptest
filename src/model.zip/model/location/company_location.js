import CoreModel from "../core/core";
import {Location} from "./location";
import {ValueOrDefault} from "../../helpers/data/mapper";
import {LOCATION_CATEGORY} from "../../constants/options/location";
import FirestoreCollection, {FireQuery} from "../../helpers/firebase/firestore/firestore_collection";

export default class CompanyLocation extends CoreModel {

	static collection = new FirestoreCollection("CompanyLocations", CompanyLocation, [])

	constructor(id, data) {
		data = data || {}
		super(id)
		this.name = data.name
		this.location = new Location(data.location || {})
		this.company = data.company
		this.map_geofence = data.map_geofence
		this.category = ValueOrDefault(LOCATION_CATEGORY, data.category, "")
		this.saved = data.saved ||  false
		this.used = data.used || false
		this.visited = data.visited || false
		this.notes = data.notes || ""
	}

	isValid = () =>{
		//TODO: Implement isValid
		return true
	}

}