import {Location} from '../location/location.js'
import CoreModel from "../core/core";


export class ShipperProfile{

  constructor(data){
    data = data || {}
    this.name = data.name || ""
    this.address = new Location(data.address || {})
    this.email = data.email || ""
    this.phone = data.phone || ""
    this.website = data.website || ""
    this.fax = data.fax || ""
    // this.carrier_authority_ids = data.carrier_authority_ids || []
  }
}

export default class Shipper extends  CoreModel {
  constructor(id, data) {
    data = data || {}
    super(id)
    if (data) {
      this.profile= new ShipperProfile(data.profile || new ShipperProfile({}))
      this.account_status=data.account_status
    }

  }
}