
const collectionModels = {
    carrier_shipment: require("./shipment/shipment").default,
    shipper_shipment: require("./shipment/shipment").default,
    carrier_quote_request: require("./shipment/quote_request").default,
    shipper_quote_request: require("./shipment/quote_request").default,
    carrier_quote_offer: require("./shipment/quote_offer").default,
    shipper_quote_offer: require("./shipment/quote_offer").default,
    carrier_vehicle: require("./asset/vehicle").default,
    carrier_trailer: require("./asset/trailer").default,
    carrier_user: require("./user/carrier_user").default,
    shipper_user: require("./user/shipper_user").default,
    carrier_company_location: require("./location/company_location").default,
    shipper_company_location: require("./location/company_location").default,
}

export function selectCollectionModel(key){
    const collectionModel = collectionModels[key] || {}
    if (collectionModel == {}){
        console.error(`collectionModel ${key} not supported`)
    }
    return collectionModel
}
