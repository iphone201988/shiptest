

class BaseModel{

  constructor(data){
    this.modify = new Date()
  }
}