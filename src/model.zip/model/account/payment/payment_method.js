import {PAYMENT_METHODS} from "../../../constants/options/money"

export class PaymentMethod {
	constructor(data) {
		data = data || {}
		this.type =  data.type
		this.account_name = data.account_name
		this.token = data.token
		this.last_digits = data.last_digits
		this.status = data.status
	}
}

export class CreditCardInfo extends PaymentMethod {
	constructor(data){
		super(data)
		this.type = "credit_card"
		this.card_type = data.card_type
		this.expiration_month = data.expiration_month
		this.expiration_year = data.expiration_year
	}
}

export class FullCreditCardInfo extends CreditCardInfo{
	constructor(data){
		super(data)
		this.number = data.number
		this.csv = data.csv
	}
}

export class ACHInfo extends PaymentMethod {
	constructor(data){
		super(data)
		this.type = PAYMENT_METHODS.ACH
	}
}

export class FullACHInfo extends ACHInfo {
	constructor(data){
		super(data)
		this.type = PAYMENT_METHODS.ach.key
		this.account_number = data.account_number
		this.routing_number = data.routing_number
	}
}

