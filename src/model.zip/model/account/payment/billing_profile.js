import {formatPhone} from "../../../helpers/data/format";
import {Location} from '../../location/location.js'
import CoreModel from "../../core/core";
import {PaymentMethod} from "./payment_method";

export class BillingProfile extends CoreModel{

	constructor(id, data) {
		data = data || {}
		super(id)
		this.label = data.label
		this.address = new Location(data.address)
		this.email = data.email
		this.phone = formatPhone(data.phone) || ""
		this.payment_method = new PaymentMethod(data.payment_method)
	}
}

